
# XM-Sim Command File
# TOOL:	xmsim	22.09-s004
#

set tcl_prompt1 {puts -nonewline "xcelium> "}
set tcl_prompt2 {puts -nonewline "> "}
set vlog_format %h
set vhdl_format %v
set real_precision 6
set display_unit auto
set time_unit module
set heap_garbage_size -200
set heap_garbage_time 0
set assert_report_level note
set assert_stop_level error
set autoscope yes
set assert_1164_warnings yes
set pack_assert_off {}
set severity_pack_assert_off {note warning}
set assert_output_stop_level failed
set tcl_debug_level 0
set relax_path_name 1
set vhdl_vcdmap XX01ZX01X
set intovf_severity_level ERROR
set probe_screen_format 0
set rangecnst_severity_level ERROR
set textio_severity_level ERROR
set vital_timing_checks_on 1
set vlog_code_show_force 0
set assert_count_attempts 1
set tcl_all64 false
set tcl_runerror_exit false
set assert_report_incompletes 0
set show_force 1
set force_reset_by_reinvoke 0
set tcl_relaxed_literal 0
set probe_exclude_patterns {}
set probe_packed_limit 4k
set probe_unpacked_limit 16k
set assert_internal_msg no
set svseed 1
set assert_reporting_mode 0
set vcd_compact_mode 0
alias . run
alias quit exit
database -open -vcd -into dump.vcd _dump.vcd1 -timescale fs
database -open -evcd -into dump.vcd _dump.vcd -timescale fs
database -open -shm -into waves.shm waves -default
probe -create -database waves tb_DES_Cryp.clk tb_DES_Cryp.des_data tb_DES_Cryp.des_decipher_en tb_DES_Cryp.des_encipher_en tb_DES_Cryp.des_key_in tb_DES_Cryp.desc_ready tb_DES_Cryp.desc_result tb_DES_Cryp.rst_n
probe -create -database waves tb_DES_Cryp.des_inst.key_schedule_inst.cin tb_DES_Cryp.des_inst.key_schedule_inst.clk tb_DES_Cryp.des_inst.key_schedule_inst.cn tb_DES_Cryp.des_inst.key_schedule_inst.cn_dn tb_DES_Cryp.des_inst.key_schedule_inst.decipher_process tb_DES_Cryp.des_inst.key_schedule_inst.des_key_in tb_DES_Cryp.des_inst.key_schedule_inst.din tb_DES_Cryp.des_inst.key_schedule_inst.dn tb_DES_Cryp.des_inst.key_schedule_inst.key_process tb_DES_Cryp.des_inst.key_schedule_inst.rkey_en tb_DES_Cryp.des_inst.key_schedule_inst.round_key tb_DES_Cryp.des_inst.key_schedule_inst.rst_n tb_DES_Cryp.des_inst.key_schedule_inst.shift_left_1 tb_DES_Cryp.des_inst.key_schedule_inst.shift_right_1

simvision -input /home/DN02/LongHB5/DV_LAB/DES/.simvision/6919_DN02_training_autosave.tcl.svcf
