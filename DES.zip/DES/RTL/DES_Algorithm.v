`include "IP.v"
`include "DES_function.v"
`include "IP_1.v"

module DES_Algorithm(
    input wire        clk,
    input wire        rst_n,
    input wire        encipher_process,
    input wire        decipher_process,
    input wire	      rkey_en,
    input wire [63:0] des_data,
    input wire [47:0] round_key,
    input wire [3:0]  r_counter,

    output reg [63:0] desc_result
);

    // ===== Internal signals =====
    wire [31:0] ln;
    wire [31:0] rn;
    wire [31:0] l_input;
    wire [31:0] r_input;
    wire [31:0] f_value;

    // ===== Initial Permutation - IP =====
    IP ip_inst (
        .des_data(des_data),
        .r_counter(r_counter),
        .encipher_process(encipher_process),
        .rkey_en(rkey_en),
        .ln(ln),
        .rn(rn),
        .l_input(l_input),
        .r_input(r_input)
    );

    // ===== DES Function =====
    DES_function des_inst (
        .r_input(r_input),
        .round_key(round_key),
        .f_value(f_value)
    );

    // ===== Final Permutation - IP_1 =====
    IP_1 ip_1_inst (
        .clk(clk),
        .rst_n(rst_n),
        .encipher_process(encipher_process),
        .decipher_process(decipher_process),
        .l_input(l_input),
        .r_input(r_input),
        .f_value(f_value),
	.ln(ln),
	.rn(rn),
        .desc_result(desc_result)
    );

endmodule

