
module DES_Controller(
  input  wire clk,
  input  wire rst_n,
  input  wire des_encipher_en,
  input  wire des_decipher_en,        // thêm input b? thi?u

  output reg  key_process,            // s?a tên chính t? (was key_procecss)
  output reg  rkey_en,
  output wire  shift_right_1,
  output wire  shift_left_1,
  output reg  decipher_process,
  output reg  encipher_process,
  output reg [3:0] r_counter,
  output wire desc_ready              // thêm output b? thi?u
);

  // ---------------- Local signals ----------------
  reg        k16_calculation;
  reg        encipher_en_sync;
  wire       k16_complete;
  wire       shift_left;


  // ---------------- Counter logic ----------------
  always @(posedge clk or negedge rst_n) begin
    if (~rst_n)
      r_counter <= 4'd0;
    else if (key_process)
      r_counter <= r_counter + 4'd1;
  end

  // ---------------- Control signal generation ----------------
  assign k16_complete = (&r_counter);
  assign rkey_en      = (|r_counter);
  assign shift_left   = k16_complete | (~rkey_en);
  assign shift_left_1  = shift_left | (r_counter==4'd1) | (r_counter==4'd8);
  assign shift_right_1 = shift_left | (r_counter==4'd7) | (r_counter==4'd14);

  // ---------------- Decipher process ----------------
  always @(posedge clk or negedge rst_n) begin
    if (~rst_n)
      decipher_process <= `DELAY 1'b0;
    else if (k16_complete & (~encipher_process)) begin
      if (k16_calculation)
        decipher_process <= `DELAY 1'b1;
      else
        decipher_process <= `DELAY 1'b0;
    end
  end

  // ---------------- Key process ----------------
  always @(posedge clk or negedge rst_n) begin
    if (~rst_n)
      key_process <= `DELAY 1'b0;
    else if (des_decipher_en | des_encipher_en)
      key_process <= `DELAY 1'b1;
    else if ((decipher_process | encipher_process) & k16_complete)
      key_process <= `DELAY 1'b0;
  end

  // ---------------- K16 calculation ----------------
  always @(posedge clk or negedge rst_n) begin
    if (~rst_n)
      k16_calculation <= `DELAY 1'b0;
    else
      k16_calculation <= `DELAY key_process & (~decipher_process) & (~encipher_process);
  end

  assign desc_ready = (~key_process) & (~encipher_process);

  // ---------------- Encipher enable sync ----------------
  always @(posedge clk or negedge rst_n) begin
    if (~rst_n)
      encipher_en_sync <= `DELAY 1'b0;
    else
      encipher_en_sync <= `DELAY des_encipher_en;
  end

  // ---------------- Encipher process ----------------
  always @(posedge clk or negedge rst_n) begin
    if (~rst_n)
      encipher_process <= `DELAY 1'b0;
    else if (encipher_en_sync)
      encipher_process <= `DELAY 1'b1;
    else if (~rkey_en)
      encipher_process <= `DELAY 1'b0;
  end

endmodule

