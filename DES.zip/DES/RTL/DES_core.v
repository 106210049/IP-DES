`include "defines.v"
`include "DES_Algorithm.v"
`include "Key_Schedule.v"
`include "DES_Controller.v"

module DES_core(
    input wire clk,
    input wire rst_n,
    input wire des_encipher_en,
    input wire des_decipher_en,
    input wire [63:0] des_data,
    input wire [63:0] des_key_in,

    output wire desc_ready,
    output wire [63:0] desc_result
);

    // ===== Internal Signals =====
    wire [47:0] round_key;
    
    wire key_process;
    wire rkey_en;
    wire shift_right_1;
    wire shift_left_1;
    wire decipher_process;
    wire encipher_process;
    wire [3:0] r_counter;

    // ===== DES Algorithm =====
    DES_Algorithm des_algorithm_inst (
        .clk(clk),
        .rst_n(rst_n),
        .encipher_process(encipher_process),
        .decipher_process(decipher_process),
	.rkey_en(rkey_en),
        .des_data(des_data),
        .round_key(round_key),
        .r_counter(r_counter),
        .desc_result(desc_result)
    );

    // ===== Key Schedule =====
    Key_Schedule key_schedule_inst (
        .clk(clk),
        .rst_n(rst_n),
        .des_key_in(des_key_in),
        .shift_left_1(shift_left_1),
        .shift_right_1(shift_right_1),
        .decipher_process(decipher_process),
        .rkey_en(rkey_en),
        .key_process(key_process),
        .round_key(round_key)
    );

    // ===== DES Controller =====
    DES_Controller controller_inst (
        .clk(clk),
        .rst_n(rst_n),
        .des_encipher_en(des_encipher_en),
        .des_decipher_en(des_decipher_en),
        .key_process(key_process),
        .rkey_en(rkey_en),
        .shift_right_1(shift_right_1),
        .shift_left_1(shift_left_1),
        .decipher_process(decipher_process),
        .encipher_process(encipher_process),
        .r_counter(r_counter),
        .desc_ready(desc_ready)
    );

endmodule

