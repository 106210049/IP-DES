module IP (
  input logic [63:0] des_data, // D? li?u ??u vào
  input wire [3:0] r_counter, // Counter vòng l?p
  input wire encipher_process, rkey_en, // Tín hi?u ?i?u khi?n
  input wire [31:0] ln, rn, // D? li?u bên trái và ph?i c?a vòng tr??c
  output logic [31:0] l_input, r_input // K?t qu? l_input, r_input
);
  // N?i b?
  wire [63:0] ip_input;
  wire [31:0] l0, r0;
  wire lr_sel;

  // X? lý Initial Permutation
  assign ip_input = {
    des_data[6], des_data[14], des_data[22], des_data[30], des_data[38], des_data[46], des_data[54], des_data[62],
    des_data[4], des_data[12], des_data[20], des_data[28], des_data[36], des_data[44], des_data[52], des_data[60],
    des_data[2], des_data[10], des_data[18], des_data[26], des_data[34], des_data[42], des_data[50], des_data[58],
    des_data[0], des_data[8], des_data[16], des_data[24], des_data[32], des_data[40], des_data[48], des_data[56],
    des_data[7], des_data[15], des_data[23], des_data[31], des_data[39], des_data[47], des_data[55], des_data[63],
    des_data[5], des_data[13], des_data[21], des_data[29], des_data[37], des_data[45], des_data[53], des_data[61],
    des_data[3], des_data[11], des_data[19], des_data[27], des_data[35], des_data[43], des_data[51], des_data[59],
    des_data[1], des_data[9], des_data[17], des_data[25], des_data[33], des_data[41], des_data[49], des_data[57]
  };

  // Chia thành L0 và R0
  assign l0 = ip_input[63:32];
  assign r0 = ip_input[31:0];

  // Quy?t ??nh giá tr? ??u vào L và R
  assign lr_sel = (encipher_process) ? (r_counter == 4'd1) : (~rkey_en);
  assign l_input = (lr_sel) ? l0 : ln;
  assign r_input = (lr_sel) ? r0 : rn;

endmodule

