+incdir+RTL
RTL/DES_core.v
TB/testbench.sv

