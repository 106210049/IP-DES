###################################################################

# Created by write_script -format dctcl on Tue Jul 29 17:07:29 2025

###################################################################

# Set the current_design #
current_design DES_core

set_units -time ns -resistance MOhm -capacitance fF -voltage V -current uA
set_operating_conditions -max ff0p88v125c -max_library saed14rvt_ff0p88v125c\
                         -min ss0p72vm40c -min_library saed14rvt_ss0p72vm40c
remove_wire_load_model
set_multibit_options -mode non_timing_driven
set_local_link_library                                                         \
{/home/Khach103/Documents/me_labs/liberty/saed14rvt_ff0p88v125c.db,/home/Khach103/Documents/me_labs/liberty/saed14rvt_ss0p72vm40c.db,/home/Khach103/Documents/me_labs/liberty/saed14rvt_tt0p8v25c.db}
set_max_capacitance 8 [current_design]
set_max_fanout 16 [current_design]
set_max_transition 0.1 [get_ports clk]
set_max_transition 0.2 [get_ports rst_n]
set_max_transition 0.2 [get_ports {des_data[63]}]
set_max_transition 0.2 [get_ports {des_data[62]}]
set_max_transition 0.2 [get_ports {des_data[61]}]
set_max_transition 0.2 [get_ports {des_data[60]}]
set_max_transition 0.2 [get_ports {des_data[59]}]
set_max_transition 0.2 [get_ports {des_data[58]}]
set_max_transition 0.2 [get_ports {des_data[57]}]
set_max_transition 0.2 [get_ports {des_data[56]}]
set_max_transition 0.2 [get_ports {des_data[55]}]
set_max_transition 0.2 [get_ports {des_data[54]}]
set_max_transition 0.2 [get_ports {des_data[53]}]
set_max_transition 0.2 [get_ports {des_data[52]}]
set_max_transition 0.2 [get_ports {des_data[51]}]
set_max_transition 0.2 [get_ports {des_data[50]}]
set_max_transition 0.2 [get_ports {des_data[49]}]
set_max_transition 0.2 [get_ports {des_data[48]}]
set_max_transition 0.2 [get_ports {des_data[47]}]
set_max_transition 0.2 [get_ports {des_data[46]}]
set_max_transition 0.2 [get_ports {des_data[45]}]
set_max_transition 0.2 [get_ports {des_data[44]}]
set_max_transition 0.2 [get_ports {des_data[43]}]
set_max_transition 0.2 [get_ports {des_data[42]}]
set_max_transition 0.2 [get_ports {des_data[41]}]
set_max_transition 0.2 [get_ports {des_data[40]}]
set_max_transition 0.2 [get_ports {des_data[39]}]
set_max_transition 0.2 [get_ports {des_data[38]}]
set_max_transition 0.2 [get_ports {des_data[37]}]
set_max_transition 0.2 [get_ports {des_data[36]}]
set_max_transition 0.2 [get_ports {des_data[35]}]
set_max_transition 0.2 [get_ports {des_data[34]}]
set_max_transition 0.2 [get_ports {des_data[33]}]
set_max_transition 0.2 [get_ports {des_data[32]}]
set_max_transition 0.2 [get_ports {des_data[31]}]
set_max_transition 0.2 [get_ports {des_data[30]}]
set_max_transition 0.2 [get_ports {des_data[29]}]
set_max_transition 0.2 [get_ports {des_data[28]}]
set_max_transition 0.2 [get_ports {des_data[27]}]
set_max_transition 0.2 [get_ports {des_data[26]}]
set_max_transition 0.2 [get_ports {des_data[25]}]
set_max_transition 0.2 [get_ports {des_data[24]}]
set_max_transition 0.2 [get_ports {des_data[23]}]
set_max_transition 0.2 [get_ports {des_data[22]}]
set_max_transition 0.2 [get_ports {des_data[21]}]
set_max_transition 0.2 [get_ports {des_data[20]}]
set_max_transition 0.2 [get_ports {des_data[19]}]
set_max_transition 0.2 [get_ports {des_data[18]}]
set_max_transition 0.2 [get_ports {des_data[17]}]
set_max_transition 0.2 [get_ports {des_data[16]}]
set_max_transition 0.2 [get_ports {des_data[15]}]
set_max_transition 0.2 [get_ports {des_data[14]}]
set_max_transition 0.2 [get_ports {des_data[13]}]
set_max_transition 0.2 [get_ports {des_data[12]}]
set_max_transition 0.2 [get_ports {des_data[11]}]
set_max_transition 0.2 [get_ports {des_data[10]}]
set_max_transition 0.2 [get_ports {des_data[9]}]
set_max_transition 0.2 [get_ports {des_data[8]}]
set_max_transition 0.2 [get_ports {des_data[7]}]
set_max_transition 0.2 [get_ports {des_data[6]}]
set_max_transition 0.2 [get_ports {des_data[5]}]
set_max_transition 0.2 [get_ports {des_data[4]}]
set_max_transition 0.2 [get_ports {des_data[3]}]
set_max_transition 0.2 [get_ports {des_data[2]}]
set_max_transition 0.2 [get_ports {des_data[1]}]
set_max_transition 0.2 [get_ports {des_data[0]}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[26]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[4]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[25]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[27]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[24]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[6]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[7]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[21]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[22]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[12]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[15]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[5]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[23]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[20]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[0]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[13]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[3]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[13]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[22]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[22]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[14]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[1]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[17]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[0]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[7]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[7]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[2]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[18]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[16]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[19]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[24]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[16]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[28]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[31]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[9]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[4]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[17]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[30]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[0]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[9]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[9]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[2]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[27]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[11]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[8]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[29]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[19]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {rn_reg[10]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[25]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[14]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[20]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[6]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[1]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[21]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[15]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[27]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[11]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[8]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[17]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[11]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[23]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[4]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[16]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[5]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[10]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[25]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[15]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[24]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[23]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[26]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[18]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[3]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[5]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[1]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[8]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[12]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[14]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[12]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[20]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[26]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[2]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[13]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[18]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {dn_reg[21]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[3]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[6]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[10]/QN}]
set_switching_activity -period 1 -toggle_rate 0 -static_probability 1          \
[get_pins {cn_reg[19]/QN}]
set_case_analysis 0 [get_ports rst_n]
create_clock [get_ports clk]  -period 1  -waveform {0 0.5}
set_clock_uncertainty 0.175  [get_clocks clk]
set_clock_transition -max -fall 0.2 [get_clocks clk]
set_clock_transition -min -rise 0.2 [get_clocks clk]
set_clock_transition -min -fall 0.2 [get_clocks clk]
set_clock_transition -max -rise 0.2 [get_clocks clk]
set_input_delay -clock clk  0.3  [get_ports clk]
set_input_delay -clock clk  0.3  [get_ports rst_n]
set_input_delay -clock clk  0.3  [get_ports des_encipher_en]
set_input_delay -clock clk  0.3  [get_ports {des_data[63]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[62]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[61]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[60]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[59]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[58]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[57]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[56]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[55]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[54]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[53]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[52]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[51]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[50]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[49]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[48]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[47]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[46]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[45]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[44]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[43]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[42]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[41]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[40]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[39]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[38]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[37]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[36]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[35]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[34]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[33]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[32]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[31]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[30]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[29]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[28]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[27]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[26]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[25]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[24]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[23]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[22]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[21]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[20]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[19]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[18]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[17]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[16]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[15]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[14]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[13]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[12]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[11]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[10]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[9]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[8]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[7]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[6]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[5]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[4]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[3]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[2]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[1]}]
set_input_delay -clock clk  0.3  [get_ports {des_data[0]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[63]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[62]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[61]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[60]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[59]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[58]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[57]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[56]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[55]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[54]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[53]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[52]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[51]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[50]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[49]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[48]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[47]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[46]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[45]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[44]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[43]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[42]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[41]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[40]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[39]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[38]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[37]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[36]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[35]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[34]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[33]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[32]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[31]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[30]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[29]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[28]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[27]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[26]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[25]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[24]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[23]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[22]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[21]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[20]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[19]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[18]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[17]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[16]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[15]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[14]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[13]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[12]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[11]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[10]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[9]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[8]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[7]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[6]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[5]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[4]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[3]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[2]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[1]}]
set_input_delay -clock clk  0.3  [get_ports {des_key_in[0]}]
set_output_delay -clock clk  0.3  [get_ports desc_ready]
set_output_delay -clock clk  0.3  [get_ports {desc_result[63]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[62]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[61]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[60]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[59]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[58]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[57]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[56]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[55]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[54]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[53]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[52]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[51]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[50]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[49]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[48]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[47]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[46]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[45]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[44]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[43]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[42]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[41]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[40]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[39]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[38]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[37]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[36]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[35]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[34]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[33]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[32]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[31]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[30]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[29]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[28]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[27]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[26]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[25]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[24]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[23]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[22]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[21]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[20]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[19]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[18]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[17]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[16]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[15]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[14]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[13]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[12]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[11]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[10]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[9]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[8]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[7]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[6]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[5]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[4]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[3]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[2]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[1]}]
set_output_delay -clock clk  0.3  [get_ports {desc_result[0]}]
set_false_path   -from [get_ports rst_n]
set compile_inbound_cell_optimization false
set compile_inbound_max_cell_percentage 10.0
